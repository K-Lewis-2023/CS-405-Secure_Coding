// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}

// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    // if empty, the size must be 0
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    // is the collection still empty?
    // if not empty, what must the size be?
    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 1);
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    add_entries(5);
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeGreaterThanEqualToSize)
{
    // ASSERT Empty Collection
    ASSERT_TRUE(collection->empty());

    // No Entries Added
    ASSERT_TRUE(collection->max_size() >= collection->size());

    // 1 Entry Added
    add_entries(1);
    ASSERT_TRUE(collection->max_size() >= collection->size());

    // 5 Total Entries Added
    add_entries(4);
    ASSERT_TRUE(collection->max_size() >= collection->size());

    // 10 Total Entries Added
    add_entries(5);
    ASSERT_TRUE(collection->max_size() >= collection->size());
}
// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapGreaterThanEqualToSize)
{
    //No Entries Added
    ASSERT_TRUE(collection->capacity() >= collection->size());

    // 1 Entry Added
    add_entries(1);
    ASSERT_TRUE(collection->capacity() >= collection->size());

    // 5 Total Entries Added
    add_entries(4);
    ASSERT_TRUE(collection->capacity() >= collection->size());

    // 10 Total Entries Added
    add_entries(5);
    ASSERT_TRUE(collection->capacity() >= collection->size());
}
// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, ResizeIncrease)
{
    //Inital Variable States
    int initSize = collection->size(); //Initial Size set to Curr Size
    int afterInc = NULL; //Increase variable set to null

    //Resize Collection
    collection->resize(5);

    //Set afterInc Variable to new collection size
    afterInc = collection->size(); 

    //ASSERT the after increase variable is larger than the initial size variable
    ASSERT_TRUE(initSize < afterInc); //IF true, resize success
}
// TODO: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizeDecrease)
{
    //Inital Variable States
    int initSize = NULL; //Initial Size set to null
    int afterInc = NULL; //Increase variable set to null

    //Assert Size is = 0
    ASSERT_EQ(collection->size(), 0);

    //Add Entries to increase collection size
    add_entries(10);

    //Set init State before resize to collection size
    initSize = collection->size();

    //Resize Collection
    collection->resize(1);

    //Set afterInc Variable to new collection size
    afterInc = collection->size();

    //ASSERT the after increase variable is smaller than the initial size variable
    ASSERT_TRUE(initSize > afterInc); //IF true, resize success
}
// TODO: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeToZero)
{
    //Verify Collection is empty
    ASSERT_TRUE(collection->empty());

    //Add Entries
    add_entries(10);

    //ASSERT Collection is not Empty
    ASSERT_FALSE(collection->empty()); 

    //Resize to 0
    collection->resize(0); 

    //ASSERT Collection is Empty
    ASSERT_TRUE(collection->empty()); 
}
// TODO: Create a test to verify clear erases the collection
TEST_F(CollectionTest, ClearCollection)
{
    //ASSERT collection is empty
    ASSERT_TRUE(collection->empty());

    //Add Test Entries
    add_entries(10);

    //ASSERT Collection is not empty
    ASSERT_FALSE(collection->empty());

    //Clear Collection
    collection->clear();
    
    //ASSERT Collection is empty
    ASSERT_TRUE(collection->empty());
}
// TODO: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseBeginEnd)
{
    //Initial Variable Declaration
    std::vector<int>::iterator begin;
    std::vector<int>::iterator end;

    //ASSERT Collection is Empty
    ASSERT_TRUE(collection->empty());

    //Add Test Entries
    add_entries(10);

    //ASSERT Collection is not empty
    ASSERT_FALSE(collection->empty());

    //Initialize Begin and End Variables
    begin = collection->begin();
    end = collection->end();

    //Erase Collection using begin and end variables
    collection->erase(begin, end);

    //ASSERT Collection is empty
    ASSERT_TRUE(collection->empty());
}
// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, CheckIncReserve)
{
    //Use int Variable to capture desired size
    int size = 10;

    //ASSERT Collection is empty
    ASSERT_TRUE(collection->empty());

    //Add entries equal to size
    add_entries(size);

    //ASSERT collection size is equal to size variable
    ASSERT_EQ(collection->size(), size);

    //Reserve double size
    collection->reserve(size * 2);

    //ASSERT collection size is same as stated size var.
    ASSERT_EQ(collection->size(), size);

    //ASSERT Collection Capacity is larger than stated size
    ASSERT_TRUE(collection->capacity() > size);

    //ASSERT Collection Capacity is double size variable
    ASSERT_EQ(collection->capacity(), (size * 2));
}
// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, CheckOutOfRangeThrow)
{
    //Add Test Entries
    add_entries(10);

    //ASSERT Collection size equals test entries size
    ASSERT_EQ(collection->size(), 10);

    //ASSERT Thrown exception when checking out of range
    EXPECT_THROW({ collection->at(collection->size() + 1); }, std::out_of_range);
}
// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative
//Test to compare set values are not equal
TEST_F(CollectionTest, CompareValuesThatNotEqual)
{
    //Initial Variables Declaration and Initialization
    int value = 1;
    int valueB = 2;

    //ASSERT Collection is empty
    ASSERT_TRUE(collection->empty());

    //Add Test Entries
    add_entries(2);

    //Set Values at positions
    collection->at(0) = value;
    collection->at(1) = valueB;

    //ASSERT the values are not the same
    ASSERT_NE(collection->at(0), collection->at(1));
}
//Test to check if value was set at a specific position
TEST_F(CollectionTest, CheckValueSet)
{
    //Initial Variable Declaration and Initialization
    int value = 58;

    //ASSERT collection is empty
    ASSERT_TRUE(collection->empty());

    //Add Test Entries
    add_entries(10);

    //Set value to the 5 position in collection
    collection->at(5) = value;

    //Assert that the 5 position in collection was set to 58
    ASSERT_EQ(collection->at(5), 58);

}