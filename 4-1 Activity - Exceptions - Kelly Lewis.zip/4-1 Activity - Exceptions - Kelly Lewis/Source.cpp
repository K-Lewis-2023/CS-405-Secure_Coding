// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
/* Name: Kelly Lewis
*  Date: 6/1/2023
*  Title: 4-1 Activity: Exceptions
*  Description: We were tasked with creating various exception
*  creation, catching, and handling. Goals were to throw several
*  exceptions, then catch the exceptions with an output of what
*  the exceptions were. Additionally, we were tasked with creating
*  a custom exception and throwing/ catching it.
*/

#include <iostream>
#include <stdexcept>
#include <exception>
#include <string>


/* Created class for custom exception,
*  designed for portability and reusability.
*  Defines the .what() message to be
*  what was stated in the custom exception throw.
*/
class MyCustExcept : public std::exception {

    private:
        std::string except = "My Custom Exception: ";

    public:
        MyCustExcept(const std::string& msg = "") {
            this->except += msg;
        }
        const char* what() {
            return (this->except).c_str();
        }
};

bool do_even_more_custom_application_logic(){

    // Throw any standard exception
    throw std::exception("Standard Exception Throw...");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}

void do_custom_application_logic(){

    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    //Begin Student Code
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {

        std::cout << "Exception caught: " << e.what() << std::endl;

    }
    
    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main

    throw MyCustExcept("Catch me in Main!");
    //End Student Code

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception

    //Begin Student Code
    if (den == 0) {
        //Standard runtime error exception to handle divide by zero attempts.
        throw std::runtime_error("Error: Attempted to divide by Zero...");
    }
    //End Student Code

    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    //Begin Student Code
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (std::runtime_error& e) {
        //Catch and print exception
        std::cout << e.what() << std::endl;
    }
    //End Student Code
}

int main()
{
    //Wrap Given Code with Try - Catch Block
    try {
        std::cout << "Exceptions Tests!" << std::endl;

        // TODO: Create exception handlers that catch (in this order):
        //  your custom exception
        //  std::exception
        //  uncaught exception 
        //  that wraps the whole main function, and displays a message to the console.
        do_division();
        do_custom_application_logic();
    }
    //Catch Custom Exception
    catch (MyCustExcept &e) {
        std::cout << e.what() << std::endl;
    }
    //Catch Standard Exception
    catch (std::exception& e) {
        std::cout << e.what() << std::endl;
    }
    //Catch missed Exceptions
    catch (...) {
        std::cout << "EXCEPTION DETECTED: Default Message!" << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu